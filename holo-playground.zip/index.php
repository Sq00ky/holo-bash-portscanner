<h1> Welcome to Holo Proving Grounds </h1>
<p> You can practice various web attacks that will be used in the Holo Network<br>Let's get started!<br></p>
<a href='./lfi.php?file=catpics.jpg'>LFI</a><br><a href='./rce.php'>RCE</a><br>
